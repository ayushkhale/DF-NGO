import React from 'react'
import Donatehero from '../components/Getinvolved/Donate/Donatehero'
import Donateform from '../components/Getinvolved/Donate/Donateform'
const Donate = () => {
  return (
    <div>
      <Donatehero />
      <Donateform/>
    </div>
  )
}

export default Donate